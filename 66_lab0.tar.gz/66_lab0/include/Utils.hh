#include<string>
#include<vector>
#include<map>
#include<forward_list>

#include<iostream>

using namespace std;

#ifndef UTILS
#define UTILS
enum estado {Nuevo, BienConservado, Roto};
#endif