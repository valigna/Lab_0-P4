#include "utilsMain.cpp"

int main() {
    // Creacion del conjunto de Objetos dados por la letra. Partes a) y b)
    std::map<string,Objeto *> mapaObjetos;
    
    // Libros...
    mapaObjetos.emplace("Nacidos de la bruma: El imperio final", new Libro("Nacidos de la bruma: El imperio final", 2022, Roto, "Brandon Sanderson", 688));
    mapaObjetos.emplace("Las Malas", new Libro("Las Malas", 2022, Nuevo, "Camila Sosa Villada", 240));
    mapaObjetos.emplace("El cocodrilo al que no le gustaba el agua", new Libro("El cocodrilo al que no le gustaba el agua", 2016, Roto, "Gemma Merino", 32));
    
    // Juegos...
    mapaObjetos.emplace("Uno", new JuegoMesa("Uno", 2022, Roto, 7, 10));
    mapaObjetos.emplace("Mazo de Cartas", new JuegoMesa("Mazo de Cartas", 2019, Nuevo, 7, 4));
    mapaObjetos.emplace("Dados", new JuegoMesa("Dados", 2020, Roto, 2, 6));

    // Consultando los objetos creados, invocando la operacion toString(). Parte c)
    cout << "-------------------------------" << endl;
    cout << "Imprimiendo los objetos creados" << endl;
    cout << "-------------------------------" << endl;
    for(auto& x: mapaObjetos){
        cout << (x.second)->toString() << endl;
    }
    cout << "-------------------------------" << endl;
    


    // Parte d)
    std::map<std::string, Ninio *> mapaNinios;
    mapaNinios.emplace("Maria Laura", new Ninio("Maria Laura", 10, "Nueva Palmira 1521", "099298190"));
    mapaNinios.emplace("Alex", new Ninio("Alex", 5, "Humberto Primo 1501", "29094141")); 


    // Parte e)
    setLink(mapaObjetos["Mazo de Cartas"],mapaNinios["Maria Laura"]);
    setLink(mapaObjetos["Nacidos de la bruma: El imperio final"],mapaNinios["Maria Laura"]);
    setLink(mapaObjetos["Dados"],mapaNinios["Maria Laura"]);
    setLink(mapaObjetos["Uno"],mapaNinios["Alex"]);
    setLink(mapaObjetos["El cocodrilo al que no le gustaba el agua"],mapaNinios["Alex"]);
    
    // Parte f)
    cout << "---------------------------------" << endl;
    cout << "Imprimiendo los objetos prestados" << endl;
    cout << "---------------------------------" << endl;
    for(auto& x: mapaNinios){
        forward_list<string> aux = (x.second)->listarObjetosPrestados();
        while ((!aux.empty())) {
            cout << "Niño: " << (x.second)->getNombre() << " Objeto: " << aux.front() << endl;
            aux.pop_front();
        }
    }
    cout << "---------------------------------" << endl;
    
     // Parte g)
     std::map<string, DTObjetoRoto *> mapaObjetosRotos;
     cout << "-----------------------------" << endl;
     cout << "Imprimiendo los objetos rotos" << endl;
     cout << "-----------------------------" << endl;
     for(auto& x: mapaObjetos){
         if((x.second)->getEstado() == Roto){
             mapaObjetosRotos.emplace((x.second)->getNombre(), new DTObjetoRoto(x.second));
             cout << (x.second)->toString() << endl;
         }
     }
     cout << "-----------------------------" << endl;
    
    // Parte h)
    for(auto& x: mapaObjetos) {
        cout << "Eliminando objeto: " << x.first << endl;
        Ninio *n = (x.second)->getPrestadoA();
        bool estabaRoto = ((x.second)->getEstado()) == Roto;
        
        // Borramos el objeto...
	Libro *aux = dynamic_cast<Libro*>(x.second);
	if(aux != NULL) {
		delete aux;
	} else {
		delete x.second;
	}

        // Consultamos la nueva lista de objetos prestados del Ninio anteriormente linkeado con el objeto...
        cout << "----------------------------------------------------------------------------------" << endl;
        cout << "Mostrando la nueva lista de objetos prestados del ninio al cual estaba linkeado..." << endl;
        cout << "----------------------------------------------------------------------------------" << endl;
        if(n != NULL) {    
            forward_list<string> lista = n->listarObjetosPrestados();
            while ((!lista.empty())) {
                cout << "Prestado A: " << n->getNombre() << endl;
                cout << "Ninio: " << (n->getNombre()) << " Objeto : " << lista.front() << endl;
                lista.pop_front();
            }
        }
        cout << "----------------------------------------------------------------------------------" << endl;

        // En caso de que fuera un objeto "Roto", consultamos nuevamente la lista de objetos rotos...
        if (estabaRoto) {
	    DTObjetoRoto *aux2 = mapaObjetosRotos[x.first];
	    delete aux2;
            mapaObjetosRotos.erase(x.first);
            cout << "--------------------------------------------------" << endl;
            cout << "Mostrando la lista actualizada de objetos rotos..." << endl;
            cout << "--------------------------------------------------" << endl;
            for(auto& y : mapaObjetosRotos) {
                cout << *(y.second) << endl;
            }
            cout << "--------------------------------------------------" << endl;
        }

    }
    


    // Liberamos la memoria pedida...
    for(auto& x: mapaNinios){
	delete x.second;
    } 

    //for(auto& x: mapaObjetosRotos){
	//delete x.second;
    //}

    return 0;
    
}
